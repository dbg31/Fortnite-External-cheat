#define _CRT_SECURE_NO_WARNINGS
#include "logger.hpp"


Logger::Logger(LogLevel level, std::ostream& output) : level(level), output(output) {}

void Logger::setLogLevel(LogLevel level) {
    this->level = level;
}

void Logger::log(const std::string& message, LogLevel msgLevel) {
    if (msgLevel >= level) {
        output << getLogLevelString(msgLevel) << " ";
        output << "\x1b[90m" << getTimeStamp() << "\033[0m ";
        output << message;
    }
}

void Logger::logln(const std::string& message, LogLevel msgLevel) {
    if (msgLevel >= level) {
        output << getLogLevelString(msgLevel) << " ";
        output << "\x1b[90m" << getTimeStamp() << "\033[0m ";
        output << message << std::endl;
    }
}
void Logger::infoln(const std::string& message) {
    logln(message, INFO);
}



void Logger::warningln(const std::string& message) {
    logln(message, WARNING);
}

void Logger::errorln(const std::string& message) {
    logln(message, ERR);
}
void Logger::info(const std::string& message) {
    log(message, INFO);
}



void Logger::warning(const std::string& message) {
    log(message, WARNING);
}

void Logger::error(const std::string& message) {
    log(message, ERR);
}

std::string Logger::getTimeStamp() const {
    std::time_t now = std::time(nullptr);
    std::tm* tm = std::localtime(&now);
    std::stringstream ss;
    ss << std::put_time(tm, "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

std::string Logger::getLogLevelString(LogLevel level) const {
    switch (level) {
    case INFO: return "                    \x1b[38;2;59;130;246m[ATOMIC]\033[0m";
    case WARNING: return "                     \033[33m[WARNING]\033[0m";
    case ERR: return "                    \033[31m[ERROR]\033[0m";
    default: return "UNKNOWN";
    }
}
