#ifndef LOG_HPP
#define LOG_HPP

#include <iostream>
#include <fstream>
#include <iomanip>
#include <ctime>
#include <sstream>

// Enum for log levels
enum LogLevel {
    INFO,
    WARNING,
    ERR
};

class Logger {
public:
    Logger(LogLevel level = INFO, std::ostream& output = std::cout);

    // Set log level
    void setLogLevel(LogLevel level);

    // Log a message
    void log(const std::string& message, LogLevel msgLevel = INFO);

    // Log a message with newline
    void logln(const std::string& message, LogLevel msgLevel = INFO);

    // Log an info message
    void info(const std::string& message);
    void infoln(const std::string& message);

    // Log a spoon message
    // Log a warning message
    void warning(const std::string& message);
    void warningln(const std::string& message);

    // Log an error message
    void error(const std::string& message);
    void errorln(const std::string& message);

private:
    LogLevel level;
    std::ostream& output;

    // Get a formatted timestamp
    std::string getTimeStamp() const;

    // Get a string representation of the log level
    std::string getLogLevelString(LogLevel level) const;
};

#endif  // LOG_HPP
